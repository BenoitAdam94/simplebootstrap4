=== Simple BootStrap 4 ===
Contributors: Benoit SAKOTE & Numa Krouchi
Tags: left-sidebar, fixed-width, custom-background
Requires at least: 5.0
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

It's a simple and lightweight bootstrap 4 theme.

It started as a school project at IFOCOP school in Paris

== Description ==
Theme desc.

== Frequently Asked Questions ==

= A question that someone might have =

Why making/using this theme when there is already WP Bootstrap Starter ?

Well, at first this theme was used to learn making theme. WP Bootstrap is a very good theme indeed, but it weight more than 10Mb, and our theme is currently at 1Mb.

== Changelog ==


= 0.3 =

Bug fixes
clean css
replace img with svg
footer img is now fluid (img-fluid)
convert indend space to tab (thank you vscode !)

= 0.2 =

Bug fixes

= 0.1 =

Initial Release



== External ressources used (everything is GPL Friendly) ==


BootStrap 4

https://getbootstrap.com/

BootStrap 4 Navwalker :

https://github.com/nicgene/bs4navwalker


SVG images are from FONT Awesome

https://fontawesome.com/